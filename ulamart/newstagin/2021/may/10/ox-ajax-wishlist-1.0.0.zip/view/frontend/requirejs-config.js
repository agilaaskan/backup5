var config = {
    map: {
        '*': {

            addAjaxWishlist:  'OX_AjaxWishlist/js/ajax-wishlist',
            wishlistAction:  'OX_AjaxWishlist/js/wishlist-actions',

        }
    }
};
