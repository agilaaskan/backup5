Guest Wishlist by BelVG
--------------------------
Guest Wish List extension, your website visitors will able to add products to Wishlists even if they are not signed up.