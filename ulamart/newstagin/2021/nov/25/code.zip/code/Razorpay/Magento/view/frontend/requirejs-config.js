var config = {
    map: {
        '*': {
            transparent: 'Magento_Payment/transparent'
        }
    }
};
