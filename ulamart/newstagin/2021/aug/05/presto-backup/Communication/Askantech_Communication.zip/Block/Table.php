<?php
/**
 * Askan Technology
 *
 * @category  AskanTech
 * @package   Askantech_Communication
 * @author    Askan
 * @copyright Copyright (c) AskanTech (https://www.askantech.com/)
 * @license   https://www.askantech.com/Communication/LICENSE.txt
 */
namespace Askantech\Communication\Block;

class Table extends \Magento\Framework\View\Element\Template
{
    /**
     * Construct
     *
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        array $data = []
    )
    {
        parent::__construct($context, $data);
       }

    /**
     * Get form action URL for POST booking request
     *
     * @return string
     */
    public function chatdata()
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $storeManager  = $objectManager->get('\Magento\Store\Model\StoreManagerInterface');
        $storeID       = $storeManager->getStore()->getStoreId(); 
        $storeName     = $storeManager->getStore()->getName();
        $customerSession = $objectManager->get('Magento\Customer\Model\Session');
        if($customerSession->isLoggedIn()) {
                $cus_id = $customerSession->getCustomer()->getId(); // get ID
        }
        $resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
        $connection = $resource->getConnection();
        $chat = $resource->getTableName('askantech_communication_chatdata');
        $chatdata = $resource->getTableName('askantech_communication_data');
        // $sql = "Select * FROM " . $tableName. " where querry_id ='".$querry."' ORDER BY created_at ASC";
        // $result = $connection->fetchAll($sql);
        $sqll = "Select * FROM " . $chatdata. " where cus_id ='".$cus_id."' AND status != 'deleted'";
        $items = $connection->fetchAll($sqll);
        if($items){
            $grid = "<table class='chathistory'>";
            $grid .= "<tr><th>Product Name</th><th>Subject</th><th>Status</th><th>Created at</th><th>Action</th></tr>";
            foreach ($items as $item) { 
                $current = date('M j Y g:i A', strtotime($item['created_at']));
                $sql = "Select * FROM " . $chat. " where querry_id ='".$item['querry_id']."' ORDER BY created_at ASC";
                $results = $connection->fetchAll($sql);
                $chat ='<div class="chat-content"><span class="close-chat">&times;</span>';
                $chat .= "<div style='display: block;height: 70px;'>";
                $chat .= "<div style='font-size: 20px;float: left;'><b>Subject: </b> ".$item['subject']."<br>
                <b>Querry regarding product: </b> ".$item['Product_name']."</div>";
                $chat .= "<div style='font-size: 20px;float:right;margin-right:20px;'><b>Status: </b> ".$item['status']."</div>";
                $chat .= '</div>';
                foreach ($results as $result) { 
                    $currenttime = date('M j Y g:i A', strtotime($result['created_at']));
                    if($result['chat_from'] == 'customer'){
                        $chat .= "<div style='background-color: #dbeaf173;box-shadow: 2px 1px 7px #f1e3e3;border-radius: 5px;padding: 6px 15px 0;padding-bottom: 30px;margin: 10px 0;'>
                        <div style='display:block;font-size: 18px;'><b>You</b></div><div>".$result['content']."</div></br>
                        <div style='float:right'>".$currenttime."</div></div>";
                    } else if($result['chat_from'] == 'admin') {
                        $chat .= "<div style='background-color: #dbeaf173;box-shadow: 2px 1px 7px #f1e3e3;border-radius: 5px;padding: 6px 15px 0;padding-bottom: 30px;margin: 10px 0;'>
                        <div style='display:block;font-size: 18px;'><b>Support</b></div><div>".$result['content']."</div></br>
                        <div style='float:right'>".$currenttime."</div></div>";
                    }
                }
                $chat .= "<form action='".$this->escapeUrl($this->getUrl('askantechcommunication/customer/form'))."' method='post'>
                <input name='form_key' type='hidden' value='".$this->getFormKey()."' />
                    <input type='hidden' name='querry_id' value='".$item['querry_id']."'>
                    <input type='hidden' name='chatfrom' value='customer'/>
                    <input type='hidden' name='chatfromname' value='".$item['contact_name']."'/>
                    <Textarea name='queries' placeholder='Write your comment..' style='margin: 10px 0px; height: 130px; padding: 12px; border: 1px solid rgb(204, 204, 204); border-radius: 4px; resize: vertical; width: 50%; display: block;' required></Textarea>
                    <input type='submit' value='Send' style='width: 20%;padding: 12px;border: 1px solid #ccc;border-radius: 4px;resize: vertical;background: #373330;color: #ffffff;'/>
                </form>";
                $chat .= "</div>";
                $grid .= "<tr><td>".$item['Product_name']."</td><td>".$item['subject']."</td><td>".$item['status']."</td><td>".$current."</td><td><button class='chat-action'>View</button><div class='chat-popup' style='display:none'>".$chat."</div></td></tr>";
            }
            $grid .= "</table>";
        } else {
            $grid = "<div>You havent contacted seller.</div>";
        }
        return $grid;
    }
}