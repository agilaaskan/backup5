<?php
/**
 * Askan Technology
 *
 * @category  AskanTech
 * @package   Askantech_Communication
 * @author    Askan
 * @copyright Copyright (c) AskanTech (https://www.askantech.com/)
 * @license   https://www.askantech.com/Communication/LICENSE.txt
 */
namespace Askantech\Communication\Controller\Customer;

class Form extends \Magento\Framework\App\Action\Action
{
    protected $resultRedirect;
    public function __construct(\Magento\Framework\App\Action\Context $context,
    \Magento\Framework\Controller\ResultFactory $result){
        parent::__construct($context);
        $this->resultRedirect = $result;
    }
	public function execute()
	{
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
        $connection = $resource->getConnection();
        $chatdata = $resource->getTableName('askantech_communication_chatdata');
        
        $post = (array) $this->getRequest()->getPost();
            if (!empty($post)) {
                $querryid = $post['querry_id'];
                $name = $post['chatfrom'];
                $fromname = $post['chatfromname'];
                $querry = $post['queries'];
                $content = str_replace("'", "\'", $querry);
                $sql = "Insert Into " . $chatdata . " (chat_from, chat_from_name, content, querry_id) Values ('".$name."','".$fromname."','".$content."','".$querryid."')";
                $saveData = $connection->query($sql);
                if($saveData){
                    $this->messageManager->addSuccess( __('Message Sent to seller. Will reach out to you soon.') );
                } else {
                    $this->messageManager->addSuccess( __('Some Problem accured try again later') );
                }
            }
            $resultRedirect = $this->resultRedirectFactory->create();
            $resultRedirect->setPath('askantechcommunication/customer/index');
            return $resultRedirect;
	}
}