<?php
/**
 * Askan Technology
 *
 * @category  AskanTech
 * @package   Askantech_Communication
 * @author    Askan
 * @copyright Copyright (c) AskanTech (https://www.askantech.com/)
 * @license   https://www.askantech.com/Communication/LICENSE.txt
 */
namespace Askantech\Communication\Block\Adminhtml;

use Magento\Backend\Block\Template;

class View extends Template
{
   public $_template = 'Askantech_Communication::view.phtml';

     public function __construct(
       \Magento\Backend\Block\Template\Context $context
   ) {
       parent::__construct($context);
   }
   public function getModificationDetails()
   {
       $id = $this->getActionsId();
       $querry = $this->getquerry();
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
        $connection = $resource->getConnection();
        $chat = $resource->getTableName('askantech_communication_chatdata');
        $chatdata = $resource->getTableName('askantech_communication_data');
        $sql = "Select * FROM " . $chat. " where querry_id ='".$querry."' ORDER BY created_at ASC";
        $result = $connection->fetchAll($sql);
        $sqll = "Select * FROM " . $chatdata. " where querry_id ='".$querry."'";
        $resultt = $connection->fetchAll($sqll);

        $grid = '';
        foreach ($resultt as $items) { 
            $grid .= "<div style='display: block;height: 70px;'>";
            $grid .= "<div style='font-size: 20px;float: left;'><b>Subject: </b> ".$items['subject']."<br>
            <b>Querry regarding product: </b> ".$items['Product_name']."</div>";
            $grid .= "<div style='font-size: 20px;float:right;'><b>Querry raised customer id: </b> ".$items['cus_id']."</div>";
            $grid .= '</div>';
        }
        foreach ($result as $item) { 
            $current = date('M j Y g:i A', strtotime($item['created_at']));
            $grid .= "<div style='background-color: #dbeaf173;box-shadow: 2px 1px 7px #f1e3e3;border-radius: 5px;padding: 6px 15px 0;padding-bottom: 30px;margin: 10px 0;'>
            <div style='display:block;font-size: 18px;'><b>From ".$item['chat_from']." ".$item['chat_from_name']." </b></div><div>".$item['content']."</div></br>
            <div style='float:right'>".$current."</div></div>";
        }
       return $grid;
   }
   public function getActionsId()
   {
       return $this->getRequest()->getParam('id');
   }
   public function getquerry()
   {
       return $this->getRequest()->getParam('querry');
   }
   public function getNewFunctionUrl(){

    return $this->getUrl('askantech_communication/index/index');

   }
}
